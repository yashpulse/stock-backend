const express = require("express");
const data = require("./routes/data");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());
const port = 3000;

app.get("/status", (req, res) => {
  res.send("Working!!!!");
});

app.use("/data", data);

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${80}`);
});
