const express = require("express");
const verify = require("../middleware/tokenVerify");
const create = require("../services/create");
const getAll = require("../services/getAll");
const data = express.Router();

data.post("/create", verify, create);
data.get("/getAll/:uid", verify, getAll);

// define the about route
/*user.get("/about", function (req, res) {
  res.send("About birds");
});*/

module.exports = data;
