//const auth = require("../firebase");

const verify = (req, res, next) => {
  //let authHeader = req.header("Authorization").split(" ");
  //  let token = authHeader[1];
  next();

  /*if (authHeader.length > 1) {
    auth
      .verifyIdToken(token)
      .then((decodedToken) => {
        res.locals.profile = decodedToken;
        next();
      })
      .catch((error) => {
        res.status(401).json({ response: error });
      });
  } else {
    res.status(401).json({ response: "Unauthorized" });
  }*/
};

module.exports = verify;
