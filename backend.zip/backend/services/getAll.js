var AWS = require("aws-sdk");

const getAll = async (req, res) => {
  AWS.config.update({
    region: "ap-south-1",
  });

  var docClient = new AWS.DynamoDB.DocumentClient();
  var table = "opt_data";
  var params = {
    TableName: table,
    KeyConditionExpression: "#kn0 = :kv0",
    ExpressionAttributeNames: {
      "#kn0": "uid",
    },
    ExpressionAttributeValues: {
      ":kv0": req.params.uid,
    },
  };

  docClient.query(params, function (err, data) {
    if (err) {
      console.log(err);
      res.status(400).json({ response: "Failed" });
    } else {
      console.log("Query succeeded.");
      res
        .status(200)
        .json({ response: "Fetch All Successfully", result: data.Items });
    }
  });
};

module.exports = getAll;
