var AWS = require("aws-sdk");

const create = async (req, res) => {
  userquery = req.body;
  AWS.config.update({
    region: "ap-south-1",
    //endpoint: "http://localhost:8000",
  });

  var docClient = new AWS.DynamoDB.DocumentClient();

  var table = "opt_data";

  var bd = req.body;

  var params = {
    TableName: table,
    Item: bd,
  };

  console.log("Adding a new item...");
  docClient.put(params, function (err, data) {
    if (err) {
      res.status(400).json({ response: "Failed" });
    } else {
      res.status(201).json({ response: "Added Successfully" });
    }
  });
};

module.exports = create;
